/**
 * RunTaxiUI starts the user interface by creating a NewTaxiUI object
 * 
 * @author Raymond Smith
 */
package edu.trident.Smith.Assignment4;

public class RunTaxiUI {

	public static void main(String[] args)
	{
		NewTaxiUI aTaxiUI = new NewTaxiUI();

	}

}/*End RunTaxiUI*/
