/**
 * MaintenanceAlert is an interface that calls and alert that maintenance is needed
 * 
 * @author Raymond Smith
 */
package edu.trident.Smith.Assignment4;


public interface MaintenanceAlert
{	
	public void maintenanceNeeded(String title, String msg);

}/*End MaintenanceAlert*/
